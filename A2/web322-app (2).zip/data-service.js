// The following two arrays should be declared "globally" within your module
var employees = new Array();
var departments = new Array();

var filesystem = require('fs');
var exports = module.exports = {};

exports.initialize = function(){
    filesystem.readFile('data/employees.json', 'utf-8', (err, data) => {employees = JSON.parse(data);});
    filesystem.readFile('data/departments.json', 'utf-8', (err, data) => {departments = JSON.parse(data);});

    return new Promise((resolve, reject) => {
        resolve("Operation was successful");
        reject("Unable to read file");
    });

};

exports.getAllEmployees = function(){
    return new Promise((resolve, reject) =>{
        resolve(employees);
        if(employees.length == 0){
            reject("No results returned");
        }
    });
};

exports.getManagers = function(){
    return new Promise((resolve, reject) => {
        let m = employees.filter(employees => employees.isManager == true);
        resolve(m);
        if(employees.length == 0){
            reject("No results returned");
        }
    });
};

exports.getDepartments = function(){
    return new Promise((resolve, reject) =>{
        resolve(departments);
        if(departments.length == 0){
            reject("No results returned");
        }
    });
};