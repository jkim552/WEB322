// The following two arrays should be declared "globally" within your module
var employees = new Array();
var departments = new Array();

const { response } = require('express');
var filesystem = require('fs');
var exports = module.exports = {};

exports.initialize = function(){
    filesystem.readFile('data/employees.json', 'utf-8', (err, data) => {employees = JSON.parse(data);});
    filesystem.readFile('data/departments.json', 'utf-8', (err, data) => {departments = JSON.parse(data);});

    return new Promise((resolve, reject) => {
        resolve("Operation was successful");
        reject("Unable to read file");
    });

};

exports.getAllEmployees = function(){
    return new Promise((resolve, reject) =>{
        resolve(employees);
        if(employees.length == 0){
            reject("No results returned");
        }
    });
};

exports.getManagers = function(){
    return new Promise((resolve, reject) => {
        let m = employees.filter(employees => employees.isManager == true);
        resolve(m);
        if(employees.length == 0){
            reject("No results returned");
        }
    });
};

exports.getDepartments = function(){
    return new Promise((resolve, reject) =>{
        resolve(departments);
        if(departments.length == 0){
            reject("No results returned");
        }
    });
};

exports.addEmployee = function(employeeData){
    employeeData.isManager = (employeeData.isManager) ? true : false;
    employeeData.employeeNum = employees.length + 1;
    employees.push(employeeData);
    return new Promise((resolve, reject) =>{
        resolve(employees);
    });
};

exports.getEmployeesByStatus = function(status){
    return new Promise((resolve, reject) => {
        let filtered = employees.filter(employees => employees.status == status);
        resolve(filtered);
        if(filtered.length == 0){
            reject("no results returned");
        }
    });
};

exports.getEmployeesByDepartment = function(department){
    return new Promise((resolve, reject) => {
        let filtered = employees.filter(employees => employees.department == department);
        resolve(filtered);
        if(filtered.length == 0){
            reject("no results returned");
        }
    });
};

exports.getEmployeesByManager = function(manager){
    return new Promise((resolve, reject) => {
        let filtered = employees.filter(employees => employees.employeeManagerNum == manager);
        resolve(filtered);
        if(filtered.length == 0){
            reject("no results returned");
        }
    });
};

exports.getEmployeesByNum = function(num){
    return new Promise((resolve, reject) => {
        let filtered = employees.filter(employees => employees.employeeNum == num);
        resolve(filtered[0]);
        if(filtered.length == 0){
            reject("no results returned");
        }
    });
};

exports.updateEmployee = function(employeeData){
    return new Promise((resolve, reject) =>{
       employees.forEach(employee =>{
           if(employee.employeeNum == employeeData.employeeNum){
               employees.splice(employeeData.employeeNum - 1, 1, employeeData);
           }
       });
       resolve(); 
    }); 
};